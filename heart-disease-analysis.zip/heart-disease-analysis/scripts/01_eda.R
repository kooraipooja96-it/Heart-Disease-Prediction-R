# =============================================================================
# Heart Disease Dataset — Exploratory Data Analysis
# Reproduces: "Exploratory Data Analysis of the Heart Disease Dataset"
# Dataset: heart.csv (303 observations, 14 variables)
# =============================================================================

# ---- 0. Setup ---------------------------------------------------------------
library(ggplot2)
library(corrplot)

dir.create("output", showWarnings = FALSE)

heart <- read.csv("data/heart.csv")

# =============================================================================
# 1. DATA QUALITY CHECKS
# =============================================================================

str(heart)
summary(heart)

# Missing values
cat("Total missing values:", sum(is.na(heart)), "\n")

# Duplicate records
n_dupes <- sum(duplicated(heart))
cat("Duplicate rows found:", n_dupes, "\n")

# Remove exact duplicate(s) -> 303 to 302 unique records
heart_unique <- heart[!duplicated(heart), ]
cat("Rows before:", nrow(heart), " | Rows after de-duplication:", nrow(heart_unique), "\n")

# Undocumented category codes (flagged, not removed)
cat("ca value counts (expected 0-3):\n")
print(table(heart$ca))
cat("thal value counts (expected 1-3):\n")
print(table(heart$thal))
# ca == 4 and thal == 0 are undocumented codes; retained per report methodology

# =============================================================================
# 2. VARIABLE TYPE CONVERSION (for categorical/statistical analysis)
# =============================================================================

heart$sex     <- factor(heart$sex, labels = c("Female", "Male"))
heart$cp      <- factor(heart$cp)
heart$fbs     <- factor(heart$fbs, labels = c("No", "Yes"))
heart$restecg <- factor(heart$restecg)
heart$exang   <- factor(heart$exang, labels = c("No", "Yes"))
heart$slope   <- factor(heart$slope, ordered = TRUE)
heart$ca      <- factor(heart$ca, ordered = TRUE)
heart$thal    <- factor(heart$thal)
heart$target  <- factor(heart$target, labels = c("No Disease", "Disease"))

# =============================================================================
# 3. DATASET OVERVIEW (Table 1a / 1b)
# =============================================================================

cat("\n--- Table 1a: Dataset Overview ---\n")
cat("Observations:", nrow(heart), "\n")
cat("Variables:", ncol(heart), "\n")
print(table(heart$target))
print(round(prop.table(table(heart$target)) * 100, 1))

# =============================================================================
# 4. DESCRIPTIVE STATISTICS — CONTINUOUS VARIABLES
# =============================================================================

continuous_vars  <- c("age", "trestbps", "chol", "thalach", "oldpeak")
categorical_vars <- c("sex", "cp", "fbs", "restecg", "exang", "slope", "ca", "thal")

desc_stats <- sapply(heart[continuous_vars], function(x) {
  c(mean = mean(x), median = median(x), sd = sd(x), var = var(x), IQR = IQR(x))
})
cat("\n--- Descriptive statistics (continuous variables) ---\n")
print(round(desc_stats, 2))

# =============================================================================
# 5. DISTRIBUTION PLOTS
# =============================================================================

# Age distribution
p_age <- ggplot(heart, aes(age)) +
  geom_histogram(fill = "#2C7FB8", bins = 15) +
  labs(title = "Distribution of Patient Age", x = "Age (years)", y = "Number of Patients") +
  theme_minimal()
ggsave("output/age_distribution.png", p_age, width = 7, height = 5)

# Cholesterol distribution
p_chol <- ggplot(heart, aes(chol)) +
  geom_histogram(fill = "#D95F02", bins = 20) +
  labs(title = "Distribution of Serum Cholesterol", x = "Cholesterol (mg/dl)", y = "Number of Patients") +
  theme_minimal()
ggsave("output/chol_distribution.png", p_chol, width = 7, height = 5)

# Max heart rate distribution
p_thalach <- ggplot(heart, aes(thalach)) +
  geom_histogram(fill = "#1B9E77", bins = 20) +
  labs(title = "Distribution of Maximum Heart Rate", x = "Max Heart Rate (thalach)", y = "Number of Patients") +
  theme_minimal()
ggsave("output/thalach_distribution.png", p_thalach, width = 7, height = 5)

# Boxplots by target for key continuous variables
for (v in continuous_vars) {
  p <- ggplot(heart, aes(x = target, y = .data[[v]], fill = target)) +
    geom_boxplot() +
    labs(title = paste(v, "by Heart Disease Status"), x = "Target", y = v) +
    theme_minimal() +
    theme(legend.position = "none")
  ggsave(paste0("output/boxplot_", v, ".png"), p, width = 6, height = 5)
}

# =============================================================================
# 6. OUTLIER DETECTION (IQR method)
# =============================================================================

detect_outliers <- function(x) {
  q1 <- quantile(x, 0.25); q3 <- quantile(x, 0.75); iqr <- q3 - q1
  lower <- q1 - 1.5 * iqr; upper <- q3 + 1.5 * iqr
  sum(x < lower | x > upper)
}

cat("\n--- Outlier counts (IQR method) ---\n")
for (v in continuous_vars) {
  n_out <- detect_outliers(heart[[v]])
  cat(sprintf("%-10s: %d outliers (%.1f%%)\n", v, n_out, 100 * n_out / nrow(heart)))
}

# =============================================================================
# 7. CORRELATION ANALYSIS
# =============================================================================

cor_matrix <- cor(heart[continuous_vars])
png("output/correlation_matrix.png", width = 800, height = 800)
corrplot::corrplot(cor_matrix, method = "color", addCoef.col = "black",
                    title = "Correlation Matrix of Continuous Variables",
                    mar = c(0, 0, 2, 0))
dev.off()

# =============================================================================
# 8. NORMALITY TESTING (Shapiro-Wilk)
# =============================================================================

cat("\n--- Shapiro-Wilk normality test (p-values) ---\n")
shapiro_results <- sapply(heart[continuous_vars], function(x) shapiro.test(x)$p.value)
print(round(shapiro_results, 4))

# =============================================================================
# 9. HYPOTHESIS TESTING
# =============================================================================

# 9a. Continuous variables vs target -> Welch t-test
cat("\n--- Welch t-test results (continuous vars vs target) ---\n")
t_results <- lapply(continuous_vars, function(v) {
  test <- t.test(heart[[v]] ~ heart$target)
  cat(sprintf("%-10s: t = %.3f, p = %.4f\n", v, test$statistic, test$p.value))
  test
})
names(t_results) <- continuous_vars

# 9b. Categorical variables vs target -> Chi-square test
cat("\n--- Chi-square test results (categorical vars vs target) ---\n")
chisq_results <- lapply(categorical_vars, function(v) {
  test <- chisq.test(table(heart[[v]], heart$target))
  cat(sprintf("%-10s: X-squared = %.3f, p = %.4g\n", v, test$statistic, test$p.value))
  test
})
names(chisq_results) <- categorical_vars

# =============================================================================
# 10. FEATURE IMPORTANCE RANKING (by p-value, ascending = strongest)
# =============================================================================

p_values <- c(
  sapply(t_results, function(x) x$p.value),
  sapply(chisq_results, function(x) x$p.value)
)
feature_ranking <- sort(p_values)

cat("\n--- Table: Ranked Feature Importance (by p-value) ---\n")
print(data.frame(variable = names(feature_ranking), p_value = signif(feature_ranking, 4)))

# =============================================================================
# 11. SUMMARY OUTPUT
# =============================================================================

cat("\n=== EDA COMPLETE ===\n")
cat("Plots saved to output/\n")
cat("See console output above for descriptive stats, test results, and rankings.\n")
