# Heart Disease Analysis (R Project)

Exploratory data analysis of the Cleveland Heart Disease dataset (303 patients, 14 variables), reproducing the statistical findings in *"Exploratory Data Analysis of the Heart Disease Dataset."*

## Structure

```
heart-disease-analysis/
├── heart-disease-analysis.Rproj   # Open this in RStudio
├── data/
│   └── heart.csv                  # Raw dataset
├── scripts/
│   └── 01_eda.R                   # Full EDA: data quality, stats, plots, hypothesis tests
├── output/                        # Generated plots (created when script runs)
└── README.md
```

## How to run

1. Open `heart-disease-analysis.Rproj` in RStudio (working directory is set automatically).
2. Install required packages if you don't have them:
   ```r
   install.packages(c("ggplot2", "corrplot"))
   ```
3. Run the script:
   ```r
   source("scripts/01_eda.R")
   ```

## What the script does

- **Data quality**: checks for missing values, duplicate rows, and undocumented category codes (`ca`, `thal`).
- **Descriptive statistics**: mean, median, SD, variance, IQR for continuous variables.
- **Visualizations**: histograms (age, cholesterol, max heart rate) and boxplots by disease status, saved to `output/`.
- **Outlier detection**: IQR method on all continuous variables.
- **Correlation analysis**: correlation matrix + heatmap of continuous variables.
- **Normality testing**: Shapiro-Wilk test on continuous variables.
- **Hypothesis testing**: Welch t-tests (continuous vs. target) and chi-square tests (categorical vs. target).
- **Feature ranking**: ranks all variables by association strength (p-value) with heart disease status.

## Key findings (from the source report)

- Exercise-response variables (thalassemia status, chest pain type, number of major vessels, max heart rate, exercise-induced angina, ST depression) are strongly associated with heart disease (all p < 0.001).
- Cholesterol and fasting blood sugar show **no** significant association (p = 0.136 and p = 0.744).
- Sample skews male (68%) and is modest in size (n = 303) — findings should be validated on an independent, more balanced sample before clinical use.

## Next steps (not included in this script)

Predictive modeling (logistic regression, random forest, XGBoost with cross-validation) is intentionally out of scope for this EDA-only project — see the source report's "Future Work" section if you'd like that added as a follow-up script.
